create view accounts as
select `portfolio`.`cash_accounts`.`acct_number`    AS `acct_number`,
       `portfolio`.`cash_accounts`.`routing_number` AS `routing_number`,
       `portfolio`.`cash_accounts`.`acct_type`      AS `acct_type`,
       `portfolio`.`cash_accounts`.`bank`           AS `bank`,
       `portfolio`.`cash_accounts`.`value`          AS `value`,
       `portfolio`.`cash_accounts`.`date_time`      AS `date_time`
from `portfolio`.`cash_accounts`
union
select `portfolio`.`investment_accounts`.`acct_number`    AS `acct_number`,
       `portfolio`.`investment_accounts`.`routing_number` AS `routing_number`,
       `portfolio`.`investment_accounts`.`acct_type`      AS `acct_type`,
       `portfolio`.`investment_accounts`.`bank`           AS `bank`,
       `portfolio`.`investment_accounts`.`value`          AS `value`,
       `portfolio`.`investment_accounts`.`date_time`      AS `date_time`
from `portfolio`.`investment_accounts`;

